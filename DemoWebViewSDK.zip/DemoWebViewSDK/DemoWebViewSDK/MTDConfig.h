//
//  MTDConfig.h
//  DemoWebViewSDK
//
//  Created by Lan Le on 11.05.22.
//

#ifndef MTDConfig_h
#define MTDConfig_h

#define FOLDER_NAME @"MetaNode"

#endif /* MTDConfig_h */
