//
//  SceneDelegate.h
//  TestWebViewSDK
//
//  Created by Lan Le on 07.05.22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

