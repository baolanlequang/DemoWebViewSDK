//
//  AppDelegate.h
//  TestWebViewSDK
//
//  Created by Lan Le on 07.05.22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

